import os,time,requests,pandas as pd,numpy as np

TOKEN=os.getenv("TELEGRAM_BOT_TOKEN","").strip()
CHAT=os.getenv("TELEGRAM_CHAT_ID","@SignalXAI_Signals")
MIN_SCORE=int(os.getenv("MIN_SCORE","75"))
SCAN_SECONDS=int(os.getenv("SCAN_SECONDS","60"))
SYMBOLS=["BTCUSDT","ETHUSDT","BNBUSDT","SOLUSDT","XRPUSDT","ADAUSDT","DOGEUSDT","AVAXUSDT","LINKUSDT"]
last_sent={}
S=requests.Session()

def klines(symbol,limit=300):
    r=S.get("https://api.binance.com/api/v3/klines",
            params={"symbol":symbol,"interval":"1m","limit":limit},timeout=15)
    r.raise_for_status()
    c=["t","o","h","l","c","v","ct","q","n","tb","tq","x"]
    d=pd.DataFrame(r.json(),columns=c)
    for x in ["o","h","l","c","v"]: d[x]=pd.to_numeric(d[x])
    d["t"]=pd.to_datetime(d["t"],unit="ms",utc=True)
    d=d.set_index("t")
    return d.resample("2min").agg({"o":"first","h":"max","l":"min","c":"last","v":"sum"}).dropna()

def analyse(d):
    d=d.copy()
    d["e9"]=d.c.ewm(span=9,adjust=False).mean()
    d["e21"]=d.c.ewm(span=21,adjust=False).mean()
    d["e50"]=d.c.ewm(span=50,adjust=False).mean()
    delta=d.c.diff()
    gain=delta.clip(lower=0).ewm(alpha=1/14,adjust=False).mean()
    loss=(-delta.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    d["rsi"]=100-100/(1+gain/loss.replace(0,np.nan))
    e12=d.c.ewm(span=12,adjust=False).mean()
    e26=d.c.ewm(span=26,adjust=False).mean()
    d["macd"]=e12-e26
    d["ms"]=d.macd.ewm(span=9,adjust=False).mean()
    prev=d.c.shift(1)
    tr=pd.concat([d.h-d.l,(d.h-prev).abs(),(d.l-prev).abs()],axis=1).max(axis=1)
    d["atr"]=tr.ewm(alpha=1/14,adjust=False).mean()
    d["vm"]=d.v.rolling(20).mean()
    return d.dropna()

def signal(symbol):
    d=analyse(klines(symbol))
    if len(d)<100:return None
    a,p=d.iloc[-1],d.iloc[-2]
    bull=bear=0;br=[];sr=[]
    if a.e9>a.e21>a.e50: bull+=2;br.append("EMA trend bullish")
    if a.e9<a.e21<a.e50: bear+=2;sr.append("EMA trend bearish")
    if a.macd>a.ms and a.macd-p.macd>0: bull+=2;br.append("MACD bullish")
    if a.macd<a.ms and a.macd-p.macd<0: bear+=2;sr.append("MACD bearish")
    if 52<=a.rsi<=68: bull+=1;br.append("RSI bullish zone")
    if 32<=a.rsi<=48: bear+=1;sr.append("RSI bearish zone")
    if a.rsi>72: bull-=2
    if a.rsi<28: bear-=2
    if a.v>a.vm*1.05:
        if a.c>a.o:bull+=1;br.append("volume confirmation")
        if a.c<a.o:bear+=1;sr.append("volume confirmation")
    if bull>=6 and bull>=bear+3: side="BUY"; reasons=br; score=bull
    elif bear>=6 and bear>=bull+3: side="SELL"; reasons=sr; score=bear
    else:return None
    conf=min(96,55+score*6)
    atrpct=float(a.atr/a.c*100)
    if not .01<=atrpct<=1.5:return None
    return side,conf,float(a.c),float(a.rsi),atrpct,reasons

def send(msg):
    if not TOKEN:
        print("[DRY RUN]\n",msg);return
    r=S.post(f"https://api.telegram.org/bot{TOKEN}/sendMessage",
             json={"chat_id":CHAT,"text":msg},timeout=15)
    r.raise_for_status()

def scan():
    for sym in SYMBOLS:
        try:
            x=signal(sym)
            if not x: continue
            side,conf,price,rsi,atr,reasons=x
            if conf<MIN_SCORE:continue
            key=sym+side
            if time.time()-last_sent.get(key,0)<600:continue
            emoji="🟢" if side=="BUY" else "🔴"
            msg=(f"⚡ SIGNALX AI\n\n{emoji} {side} — {sym}\n"
                 f"📊 Confidence: {conf}%\n💰 Price: {price:.8g}\n"
                 f"📈 RSI: {rsi:.1f}\n📐 Volatility: {atr:.3f}%\n\n"
                 f"🔎 Confirmations:\n"+"\n".join("• "+r for r in reasons[:4])+
                 "\n\n⚠️ Educational signal. No guaranteed profit.")
            send(msg);last_sent[key]=time.time()
        except Exception as e: print("WARN",sym,e)

print("SignalX AI engine running...")
while True:
    scan();time.sleep(SCAN_SECONDS)