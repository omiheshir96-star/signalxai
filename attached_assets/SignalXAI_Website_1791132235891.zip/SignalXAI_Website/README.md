# SignalX AI Website + Signal Engine

A mobile-friendly FastAPI website connected to the SignalX AI crypto scanner. It uses the same EMA/RSI/MACD/volume/volatility approach as the starter engine and only displays signals produced by the backend. It does **not** invent demo BUY/SELL signals.

## 1) Install
Python 3.11+ is recommended.

```bash
pip install -r requirements.txt
```

## 2) Configure Telegram
Copy `.env.example` to `.env` and put your **new** BotFather token there. Never paste the token into the website frontend or share it publicly.

```env
TELEGRAM_BOT_TOKEN=YOUR_TOKEN
TELEGRAM_CHAT_ID=@SignalXAI_Signals
MIN_SCORE=75
SCAN_SECONDS=60
```

## 3) Start website

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open: `http://127.0.0.1:8000`

The backend scans Binance public crypto data and, when a setup passes the filters, stores it in SQLite and posts it to the Telegram channel.

## 4) Adsterra
The frontend contains an `ADSTERRA AD SPACE` placeholder. After you create your Adsterra publisher account, replace that block with the ad code Adsterra gives you. Do not invent an ad code.

## 5) Important next upgrades before public/real-money use
- Multi-timeframe confirmation (2m + 5m + 15m)
- Real historical backtesting and walk-forward testing
- Automatic WIN/LOSS evaluation after a defined expiry
- Persistent performance statistics
- News/high-impact volatility filter
- Forex data provider
- Admin login and rate limiting
- Better error handling and monitoring

This is an educational/paper-trading system. No accuracy or profit is guaranteed. Short-timeframe trading can cause rapid losses.
